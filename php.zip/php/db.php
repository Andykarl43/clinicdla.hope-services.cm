<?php

try {
    // $db = new PDO('mysql:host=localhost;dbname=apfood_syges_btp;charset=utf8', 'apfood_syges_btp_root', 'jk5N{^-&znT{');
    $db = new PDO('mysql:host=localhost;dbname=ch6183b13e1fa50_clinic;charset=utf8', 'ch6183b13e1fa50_clinic_root', '!&bxmMs[KB%l');
} catch (PDOException $e) {
    die('Erreur: ' . $e->getMessage());
}
?>