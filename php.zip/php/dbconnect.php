<?php
//error_reporting(0);
ob_start();
session_start();


//DEFINE("BASE_URL","http://cipetbhopal.com/");
DEFINE("BASE_URL","https://clinicdla.hope-services.cm/");

DEFINE ('DB_USER', 'ch6183b13e1fa50_clinic_root');
DEFINE ('DB_PSWD', '!&bxmMs[KB%l');
DEFINE ('DB_HOST', 'localhost');
DEFINE ('DB_NAME', 'ch6183b13e1fa50_clinic');

date_default_timezone_set('Africa/Douala');

$conn = new mysqli(DB_HOST, DB_USER, DB_PSWD, DB_NAME);
if ($conn->connect_error)
    die("Failed to connect database " . $conn->connect_error);
