<?php

include("php/dbconnect.php");


if (isset($_REQUEST['id'])) {
    $id_exa = $_REQUEST['id'];


    $query = "DELETE FROM examen WHERE id_exa='$id_exa'";
    $sql = $conn->query($query);


    if ($sql) {
        echo "<script>
                window.location.href='liste_examen.php?witness=1';
            </script>";
    } else {

        echo "<script>
                window.location.href='liste_examen.php?witness=-1';
            </script>";
    }
}


?>